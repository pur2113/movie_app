# ticket-booking-app
Created the backend of a Ticket Booking App using Spring Boot

# NOTE:
Just the backend of the application has been implemented. <br />
I will upload a guide for api calls, and a sql file for data dump soon. 
