package com.ciq.application.service;

import com.ciq.application.entity.Movie;
import com.ciq.application.response.BaseResponse;
import com.ciq.application.respository.MovieRepository;

import com.ciq.application.utils.StringConstants;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
@Slf4j
@Service
public class MovieService {
    @Autowired
    private MovieRepository movieRepository;

    public BaseResponse saveMovie(Movie movie)
    {
        log.info(String.format(StringConstants.IN_FUNCTION, "saveMovie", "request-" + movie.toString()));
        BaseResponse response = new BaseResponse();
        movieRepository.save(movie);
        response.setResponseCode(BaseResponse.SUCCESS_RESPONSE_DEFAULT);
        response.setResponseMessage("Movie Added Successfully");
        return response;
    }

    public Movie getMovieById(Integer id)
    {
        log.info(String.format(StringConstants.IN_FUNCTION, "getMovieById", "request-" + id.toString()));
        return movieRepository.findById(id).orElse(null);
    }

    public Movie getMovieByName(String name)
    {
        log.info(String.format(StringConstants.IN_FUNCTION, "getMovieByName", "request-" + name.toString()));
        return movieRepository.findByName(name);
    }
}
