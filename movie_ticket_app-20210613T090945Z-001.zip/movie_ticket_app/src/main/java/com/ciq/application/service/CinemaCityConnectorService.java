package com.ciq.application.service;

import java.awt.event.InputEvent;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import com.ciq.application.entity.Cinema;
import com.ciq.application.entity.CinemaCityConnector;
import com.ciq.application.entity.City;
import com.ciq.application.entity.Movie;
import com.ciq.application.request.AddCinemaCityConnectorRequest;
import com.ciq.application.response.BaseResponse;
import com.ciq.application.respository.CinemaCityConnectorRepository;

import com.ciq.application.utils.StringConstants;
import lombok.extern.flogger.Flogger;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Slf4j
@Service
public class CinemaCityConnectorService {
    @Autowired
    private CinemaCityConnectorRepository cinemaCityConnectorRepository;

    public BaseResponse saveCinemaCityConnector(AddCinemaCityConnectorRequest request)
    {
        log.info(String.format(StringConstants.IN_FUNCTION, "saveCinemaCityConnector", "request-" + request.toString()));
        CinemaService cinemaService = new CinemaService();
        Cinema cinema = cinemaService.getCinemaById(request.getCinemaId());
        CityService cityService = new CityService();
        City city = cityService.getCityById(request.getCityId());

        CinemaCityConnector newMap = new CinemaCityConnector();
        newMap.setCinema(cinema);
        newMap.setCity(city);
        cinemaCityConnectorRepository.save(newMap);

        BaseResponse response = new BaseResponse();
        response.setResponseCode(BaseResponse.SUCCESS_RESPONSE_DEFAULT);
        response.setResponseMessage("Connector added successfully");

        return response;
    }

    public CinemaCityConnector GetMappingById(Integer id)
    {
        log.info(String.format(StringConstants.IN_FUNCTION, "GetMappingById", "request-" + id.toString()));

        return cinemaCityConnectorRepository.findById(id).orElse(null);
    }

    public CinemaCityConnector GetMappingByCinema(Cinema cinema)
    {
        log.info(String.format(StringConstants.IN_FUNCTION, "GetMappingByCinema", "request-" + cinema.toString()));
        return cinemaCityConnectorRepository.findByCinema(cinema);
    }

    public List<CinemaCityConnector> GetMappingsByCity(City city)
    {
        log.info(String.format(StringConstants.IN_FUNCTION, "GetMappingByCity", "request-" + city.toString()));
        return cinemaCityConnectorRepository.findAllByCity(city);
    }

    public Set<Cinema> getAllCinemasByCity(City city)
    {
        log.info(String.format(StringConstants.IN_FUNCTION, "getAllCinemasByCity", "request-" + city.toString()));
        List<CinemaCityConnector> allMaps = GetMappingsByCity(city);
        Set<Cinema> allCinemas = new HashSet<Cinema>();
        for(int i=0; i<allMaps.size(); i++)
        {
            allCinemas.add(allMaps.get(i).getCinema());
        }
        return allCinemas;
    }

    public Set<Movie> getAllMoviesByCity(City city)
    {
        log.info(String.format(StringConstants.IN_FUNCTION, "getAllMoviesByCity", "request-" + city.toString()));
        Set<Cinema> allCinemas = getAllCinemasByCity(city);
        Set<Movie> allMovies = new HashSet<Movie>();
        CinemaMovieConnectorService cmMapService = new CinemaMovieConnectorService();
        for(Cinema tempCinema : allCinemas)
        {
            allMovies.addAll(cmMapService.getMoviesByCinema(tempCinema));
        }
        return allMovies;
    }
}
