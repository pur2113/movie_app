package com.ciq.application.respository;

import java.util.List;

import com.ciq.application.entity.Cinema;
import com.ciq.application.entity.CinemaCityConnector;
import com.ciq.application.entity.City;

import org.springframework.data.jpa.repository.JpaRepository;

public interface CinemaCityConnectorRepository extends JpaRepository<CinemaCityConnector,Integer>{
    CinemaCityConnector findByCinema(Cinema cinema);
    List<CinemaCityConnector> findAllByCity(City city);
}
