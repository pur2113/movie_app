package com.ciq.application.request;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AddCinemaCityConnectorRequest {
    private Integer cinemaId;
    private Integer cityId;
}
