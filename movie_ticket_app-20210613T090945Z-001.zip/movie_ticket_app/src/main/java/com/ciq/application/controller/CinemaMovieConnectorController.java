package com.ciq.application.controller;

import java.util.List;
import java.util.Set;

import com.ciq.application.entity.Cinema;
import com.ciq.application.entity.CinemaMovieConnector;
import com.ciq.application.entity.Movie;
import com.ciq.application.request.AddCinemaMovieConnectorRequest;
import com.ciq.application.request.BookSeatsRequest;
import com.ciq.application.response.BaseResponse;
import com.ciq.application.service.CinemaMovieConnectorService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class CinemaMovieConnectorController {
    @Autowired
    private CinemaMovieConnectorService cinemaMovieConnectorService;

    @ResponseBody
    @PostMapping("/addCMMap")
    public BaseResponse addCinemaMovieConnector(@RequestBody AddCinemaMovieConnectorRequest request)
    {
        return cinemaMovieConnectorService.saveCinemaMovieConnector(request);
    }

    @ResponseBody
    @GetMapping("/getCMMapById/{id}")
    public CinemaMovieConnector getCinemaMovieConnectorById(@PathVariable Integer id)
    {
        return cinemaMovieConnectorService.GetMappingById(id);
    }

    @ResponseBody
    @GetMapping("/getCMMapsByCinema")
    public List<CinemaMovieConnector> getCinemaMovieConnectorsByCinema(@RequestBody Cinema cinema)
    {
        return cinemaMovieConnectorService.GetMappingsByCinema(cinema);
    }

    @ResponseBody
    @GetMapping("/getCMMapsByMovie")
    public List<CinemaMovieConnector> getCinemaMovieConnectorsByMovie(@RequestBody Movie movie)
    {
        return cinemaMovieConnectorService.GetMappingsByMovie(movie);
    }

    @ResponseBody
    @GetMapping("/getBookedSeats/{id}")
    public Set<Integer> getBookedSeatsById(@PathVariable Integer id)
    {
        return cinemaMovieConnectorService.getBookedSeatsById(id);
    }

    @ResponseBody
    @PostMapping("/bookNewSeats")
    public BaseResponse bookNewSeatsById(@RequestBody BookSeatsRequest request)
    {
        return cinemaMovieConnectorService.bookSeatsById(request);
    }
}
