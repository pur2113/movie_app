package com.ciq.application.respository;

import java.util.List;

import com.ciq.application.entity.Cinema;
import com.ciq.application.entity.CinemaMovieConnector;
import com.ciq.application.entity.Movie;

import org.springframework.data.jpa.repository.JpaRepository;

public interface CinemaMovieConnectorRepository extends JpaRepository<CinemaMovieConnector,Integer>{
    List<CinemaMovieConnector> findAllByCinema(Cinema cinema);
    List<CinemaMovieConnector> findAllByMovie(Movie movie);
}
