package com.ciq.application.request;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AddCinemaMovieConnectorRequest{
    private Integer cinemaId;
    private Integer movieId;
}