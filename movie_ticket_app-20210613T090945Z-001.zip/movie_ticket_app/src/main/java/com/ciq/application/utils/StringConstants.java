package com.ciq.application.utils;

public class StringConstants {
    public static final String IN_FUNCTION = "Inside %s method with params :: %s";
}
