package com.ciq.application.service;

import com.ciq.application.respository.UserRepository;
import com.ciq.application.entity.User;
import com.ciq.application.response.BaseResponse;

import com.ciq.application.utils.StringConstants;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
@Slf4j
@Service
public class UserService {
    @Autowired
    private UserRepository userRepository;

    public BaseResponse saveUser(User user)
    {
        log.info(String.format(StringConstants.IN_FUNCTION, "saveUser", "request-" + user.toString()));
        BaseResponse response = new BaseResponse();
        userRepository.save(user);
        response.setResponseCode(BaseResponse.SUCCESS_RESPONSE_DEFAULT);
        response.setResponseMessage("User Registration Successfull");
        return response;
    }

    public User getUserById(Integer id)
    {
        log.info(String.format(StringConstants.IN_FUNCTION, "getUserById", "request-" + id.toString()));
        return userRepository.findById(id).orElse(null);
    }

    public User getUserByUsername(String username)
    {
        log.info(String.format(StringConstants.IN_FUNCTION, "getUserByUsername", "request-" + username.toString()));
        return userRepository.findByUsername(username);
    }
}
