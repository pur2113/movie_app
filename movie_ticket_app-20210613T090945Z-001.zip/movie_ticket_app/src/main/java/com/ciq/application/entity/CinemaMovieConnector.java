package com.ciq.application.entity;

import lombok.Getter;
import lombok.Setter;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.*;

@Entity
@Table(name = "cinema_movie_Connector")
@Getter
@Setter
public class CinemaMovieConnector {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Integer id;
    private Cinema cinema;
    private Movie movie;
    @Column(name = "booked_seats")
    private Set<Integer> bookedSeats = new HashSet<>();

}
