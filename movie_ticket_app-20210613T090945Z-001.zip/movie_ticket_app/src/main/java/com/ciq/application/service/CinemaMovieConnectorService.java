package com.ciq.application.service;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import com.ciq.application.entity.Cinema;
import com.ciq.application.entity.CinemaMovieConnector;
import com.ciq.application.entity.Movie;
import com.ciq.application.request.AddCinemaMovieConnectorRequest;
import com.ciq.application.request.BookSeatsRequest;
import com.ciq.application.response.BaseResponse;
import com.ciq.application.respository.CinemaMovieConnectorRepository;

import com.ciq.application.utils.StringConstants;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
@Slf4j
@Service
public class CinemaMovieConnectorService{
    @Autowired
    private CinemaMovieConnectorRepository cinemaMovieConnectorRepository;

    public BaseResponse saveCinemaMovieConnector(AddCinemaMovieConnectorRequest request)
    {
        log.info(String.format(StringConstants.IN_FUNCTION, "saveCinemaMovieConnector", "request-" + request.toString()));

        CinemaService cinemaService = new CinemaService();
        Cinema cinema = cinemaService.getCinemaById(request.getCinemaId());
        MovieService movieService = new MovieService();
        Movie movie = movieService.getMovieById(request.getMovieId());

        CinemaMovieConnector newMap = new CinemaMovieConnector();
        newMap.setCinema(cinema);
        newMap.setMovie(movie);
        cinemaMovieConnectorRepository.save(newMap);

        BaseResponse response = new BaseResponse();
        response.setResponseCode(BaseResponse.SUCCESS_RESPONSE_DEFAULT);
        response.setResponseMessage("Connector saved successfully");

        return response;
    }

    public CinemaMovieConnector GetMappingById(Integer id)
    {
        log.info(String.format(StringConstants.IN_FUNCTION, "GetMappingById", "request-" + id.toString()));

        return cinemaMovieConnectorRepository.findById(id).orElse(null);
    }

    public List<CinemaMovieConnector> GetMappingsByCinema(Cinema cinema)
    {
        log.info(String.format(StringConstants.IN_FUNCTION, "GetMappingByCinema", "request-" + cinema.toString()));
        return cinemaMovieConnectorRepository.findAllByCinema(cinema);
    }

    public List<CinemaMovieConnector> GetMappingsByMovie(Movie movie)
    {
        log.info(String.format(StringConstants.IN_FUNCTION, "GetMappingsByMovie", "request-" + movie.toString()));
        return cinemaMovieConnectorRepository.findAllByMovie(movie);
    }

    public Set<Integer> getBookedSeatsById(Integer id)
    {
        log.info(String.format(StringConstants.IN_FUNCTION, "getBookedSeatsById", "request-" + id.toString()));
        CinemaMovieConnector ourMap = GetMappingById(id);
        return ourMap.getBookedSeats();
    }

    public BaseResponse bookSeatsById(BookSeatsRequest request)
    {
        log.info(String.format(StringConstants.IN_FUNCTION, "bookSeatsById", "request-" + request.toString()));
        CinemaMovieConnector ourMap = GetMappingById(request.getId());
        Set<Integer> newSeats = ourMap.getBookedSeats();
        newSeats.addAll(request.getBookSeats());
        ourMap.setBookedSeats(newSeats);

        cinemaMovieConnectorRepository.save(ourMap);

        BaseResponse response = new BaseResponse();
        response.setResponseCode(BaseResponse.SUCCESS_RESPONSE_DEFAULT);
        response.setResponseMessage("Booked Seats Successfully");
        
        return response;
    }

    public Set<Movie> getMoviesByCinema(Cinema cinema)
    {
        log.info(String.format(StringConstants.IN_FUNCTION, "getMovieByCinema", "request-" + cinema.toString()));
        List<CinemaMovieConnector> allMaps = GetMappingsByCinema(cinema);
        Set<Movie> allMovies = new HashSet<Movie>();
        for(int i=0; i<allMaps.size(); i++)
        {
            allMovies.add(allMaps.get(i).getMovie());
        }
        return allMovies;
    }
}
