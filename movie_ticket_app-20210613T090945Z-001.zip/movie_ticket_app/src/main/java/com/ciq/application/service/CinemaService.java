package com.ciq.application.service;

import com.ciq.application.entity.Cinema;
import com.ciq.application.response.BaseResponse;
import com.ciq.application.respository.CinemaRepository;

import com.ciq.application.utils.StringConstants;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
@Slf4j
@Service
public class CinemaService {
    @Autowired
    private CinemaRepository cinemaRepository;

    public BaseResponse saveCinema(Cinema cinema)
    {
        log.info(String.format(StringConstants.IN_FUNCTION, "saveCinema", "request-" + cinema.toString()));
        BaseResponse response = new BaseResponse();
        cinemaRepository.save(cinema);
        response.setResponseCode(BaseResponse.SUCCESS_RESPONSE_DEFAULT);
        response.setResponseMessage("Cinema Added Successfully");
        return response;
    }

    public Cinema getCinemaById(Integer id)
    {
        log.info(String.format(StringConstants.IN_FUNCTION, "getCinemaById", "request-" + id.toString()));
        return cinemaRepository.findById(id).orElse(null);
    }

    public Cinema getCinemaByName(String name)
    {
        log.info(String.format(StringConstants.IN_FUNCTION, "getCinemaByName", "request-" + name.toString()));
        return cinemaRepository.findByName(name);
    }
}
