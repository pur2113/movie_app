package com.ciq.application.controller;

import java.util.List;
import java.util.Set;

import com.ciq.application.entity.Cinema;
import com.ciq.application.entity.CinemaCityConnector;
import com.ciq.application.entity.City;
import com.ciq.application.entity.Movie;
import com.ciq.application.request.AddCinemaCityConnectorRequest;
import com.ciq.application.response.BaseResponse;
import com.ciq.application.service.CinemaCityConnectorService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

@RestController
public class CinemaCityConnectorController {
    @Autowired
    private CinemaCityConnectorService cinemaCityConnectorService;

    @ResponseBody
    @PostMapping("/addCCMap")
    public BaseResponse addCinemaCityConnector(@RequestBody AddCinemaCityConnectorRequest request)
    {
        return cinemaCityConnectorService.saveCinemaCityConnector(request);
    }

    @ResponseBody
    @GetMapping("/getCCMapById/{id}")
    public CinemaCityConnector getCinemaCityConnectorById(@PathVariable Integer id)
    {
        return cinemaCityConnectorService.GetMappingById(id);
    }

    @ResponseBody
    @GetMapping("/getCCMapByCinema")
    public CinemaCityConnector getCinemaCityConnectorByCinema(@RequestBody Cinema cinema)
    {
        return cinemaCityConnectorService.GetMappingByCinema(cinema);
    }

    @ResponseBody
    @GetMapping("/getCCMapByCity")
    public List<CinemaCityConnector> getCinemaCityConnectorByCity(@RequestBody City city)
    {
        return cinemaCityConnectorService.GetMappingsByCity(city);
    }

    @ResponseBody
    @GetMapping("/getMoviesByCity")
    public Set<Movie> getAllMoviesByCity(@RequestBody City city)
    {
        return cinemaCityConnectorService.getAllMoviesByCity(city);
    }
}
